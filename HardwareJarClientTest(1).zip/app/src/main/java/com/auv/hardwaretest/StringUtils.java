package com.auv.hardwaretest;

/**
 * @author LiChuang
 * @version 1.0
 * @ClassName StringUtils
 * @Description TODO 类描述
 * @since 2020/2/6 11:10
 **/
class StringUtils {


    static boolean isEmpty(String value){
        return  !isNotEmpty(value);
    }

    static boolean isNotEmpty(String value){
        return (null!=value && !"".equals(value) && value.length()>0);
    }

}
