package com.auv.hardwaretest;

import android.app.Application;
import android.util.Log;
import android.widget.Toast;

import com.auv.alink.devicesdk.app.AUVIotApplication;

import static com.aliyun.alink.linksdk.tools.ThreadTools.runOnUiThread;

public class MyApplication extends Application {
    public    String  productKey= "";
    public   String  deviceName= "";
    public    String deviceSecret= "";
    @Override
    public void onCreate() {
        super.onCreate();
        String  deviceInfo = "{" +
                "'productKey':'"+productKey+"'," +
                "'deviceName':'"+deviceName+"'," +
                "'deviceSecret':'"+deviceSecret+"'" +
                "}";
        //连接阿里云服务器
        AUVIotApplication.getInstance(MyApplication.this, deviceInfo, (success, msg) -> {
            String info =  success?"成功":"失败";
            showToast("连接"+info+";"+msg);
        });
    }

    /**
     * 提示框
     * @param message  提示信息
     */
    public void showToast(final String message) {
        Log.d("showToast() ", " message = " + message);
        runOnUiThread(() -> {
            int  time = Toast.LENGTH_SHORT;
            try{
                Toast.makeText(getApplicationContext(), message,time).show();
            }catch (Exception e){
                e.printStackTrace();
            }

        });
    }
}
